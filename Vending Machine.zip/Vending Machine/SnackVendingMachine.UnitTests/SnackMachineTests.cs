using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SnackVendingMachine.UnitTests
{
    [TestClass]
    public class SnackMachineTests
    {
        [TestMethod]
        public void WhenSelectingValidSnackIndex_ShouldReturnCorrectProductDetails()
        {
            //Arrange
            var expectedSnack = new Snack
            {
                Stock = 2,
                ColumnIndex = 0,
                RowIndex = "A",
                Name = "Coca Cola",
                Price = 3.5f
            };
            var sut = CreateSut();

            //Act
            var actualSnack = sut.GetProductDetails("A", 0);

            //Assert

            Assert.AreEqual(expectedSnack.Name, actualSnack.Name);
            Assert.AreEqual(expectedSnack.Price, actualSnack.Price);
            Assert.AreEqual(expectedSnack.Stock, actualSnack.Stock);

        }

        [TestMethod]
        public void WhenValidatingMoney_ShouldValidateCorrectly()
        {
            //Arrange
            var money = new Note(Currency.USD, 20);
            var sut = CreateSut();

            //Act
            var IsValidation = sut.ValidateMoney(money);

            //Assert

            Assert.IsTrue(IsValidation);

        }

        [TestMethod]
        public void WhenMoneyIsEnoughToBuy_MakeTheProsedure()
        {
            //Arrange
              
            var sut = CreateSut();
            var payAmount = new Note(Currency.USD , 20);

            //Act
            sut.PayMoney(payAmount);
             var IsMoneyEnough = sut.IsMoneyEnoughToBuySnack("A" , 1  );


            //Assert
            Assert.IsTrue(IsMoneyEnough);
            


        }


        [TestMethod]
        public void VendingMachingShouldCalculateChangeSuccessfuly()
        {
            //Arrange

            var sut = CreateSut();
            var money = new Note(Currency.USD, 20);

            //Act
            sut.PayMoney(money);
            var actualChange = sut.CalculateChange("A", 1);
           


            //Assert
            Assert.AreEqual(16.5f, actualChange);



        }

        [TestMethod]
        public void GetTheProductPrice()
        {
            //Arrange

            var sut = CreateSut();
            var expetedPrice = 3.5;

            //Act
            
            var actualPrice = sut.GetProductPrice("A", 1);


            //Assert
            Assert.AreEqual(expetedPrice, actualPrice);

        }

        [TestMethod]
        public void WhenDespensingAllSnacksStock_SnackShouldNotBeAvailable()
        {
            //Arrange

            var sut = CreateSut();
            var money = new Note(Currency.USD, 20);

            //Act and Assert


            sut.PayMoney(money);
            var snack = sut.DispenceSnack("A", 0);
            Assert.AreEqual(1, snack.Stock);
            sut.PayMoney(money);
            snack = sut.DispenceSnack("A", 0);
            Assert.AreEqual(0, snack.Stock);
            var actualSnackInVendingMachine = sut.GetProductDetails("A", 0);
            Assert.AreEqual(snack.Name, actualSnackInVendingMachine.Name);
            Assert.AreEqual(snack.Price, actualSnackInVendingMachine.Price);
            Assert.AreEqual(snack.Stock, actualSnackInVendingMachine.Stock);
            var isSnackAvailable = sut.IsSnackAvailable("A", 0);
            Assert.IsFalse(isSnackAvailable);
        }





        private SnackMachine CreateSut()
        {
            var snacks
                = new Snack[]
                {
                    new Snack
                    {
                        Stock = 2,
                        ColumnIndex = 0,
                        RowIndex = "A",
                        Name = "Coca Cola",
                        Price = 3.5f 
                    } ,

                     new Snack
                    {
                        Stock = 2,
                        ColumnIndex = 1,
                        RowIndex = "A",
                        Name = "Sprite",
                        Price = 3.5f
                    } ,

                       new Snack
                    {
                        Stock = 2,
                        ColumnIndex = 0,
                        RowIndex = "B",
                        Name = "Snickers",
                        Price = 3f
                    } ,
                };

            return new SnackMachine(snacks);
        }


    }
}


