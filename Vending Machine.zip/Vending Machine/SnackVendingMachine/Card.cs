﻿using System;

namespace SnackVendingMachine
{
    public class Card : Money
    {

        public Card(Currency currency, string cardHolderName, string cardName, DateTime expirationDate, string cvv) : base(currency)
        {
            CardHolderName = cardHolderName;
            CardNumer = cardName;
            ExpirationDate = expirationDate;
            CVV = cvv;
        }

        public string CardHolderName { get; }
        public string CardNumer { get;  }
        public DateTime ExpirationDate { get;  }
        public string CVV { get; }
    }
}
