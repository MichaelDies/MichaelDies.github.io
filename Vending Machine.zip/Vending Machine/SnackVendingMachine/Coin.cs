﻿using System;

namespace SnackVendingMachine
{
    //sub type
    public class Coin : Money
    {

        public Coin(Currency currency, int cents) : base(currency)
        {
            if (cents < 10 && cents > 100)
            {
                throw new Exception("Coin Value can only be 10c, 20c, 50c or $1");
            }

            Cents = cents;
        }
        public int Cents { get; }
    }
}
