﻿namespace SnackVendingMachine
{
    public enum Currency
    {
        USD
    }
}
