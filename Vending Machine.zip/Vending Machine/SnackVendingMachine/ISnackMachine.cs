﻿namespace SnackVendingMachine
{
    public interface ISnackMachine
    {
        Snack GetProductDetails(string rowIndex, int columnIndex);
        bool ValidateMoney(Money money);
        void PayMoney(Money money);
        bool IsMoneyEnoughToBuySnack(string rowIndex, int columnIndex);
        float CalculateChange(string rowIndex, int columnIndex);
        float GetProductPrice(string rowIndex, int columnIndex);
        bool IsSnackAvailable(string rowIndex, int columnIndex);
    }
}
