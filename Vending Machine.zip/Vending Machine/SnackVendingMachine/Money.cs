﻿namespace SnackVendingMachine
{
    //Parent type
    public abstract class Money
    {

        public Currency Currency { get;  }

        protected Money(Currency currency)
        {
            Currency = currency;
        }
    }
}
