﻿using System;

namespace SnackVendingMachine
{
    public class Note : Money
    {
        public Note(Currency currency, int value) : base(currency)
        {
            if(value != 20 && value != 50)
            {
                throw new Exception("Note can only be 20 or 50 dollar notes");
            }

            Value = value;
        }

        public int Value { get; }

        
    }
}
