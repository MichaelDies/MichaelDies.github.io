﻿namespace SnackVendingMachine
{
    public class Snack
    {
        public string RowIndex { get; set; }
        public int ColumnIndex { get; set; }
        public string Name { get; set; }
        public float Price { get; set; }
        public int Stock { get; set; }
    }
}
