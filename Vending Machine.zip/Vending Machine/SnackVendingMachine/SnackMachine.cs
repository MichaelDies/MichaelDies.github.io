﻿using System;
using System.Linq;

namespace SnackVendingMachine
{
    public class SnackMachine : ISnackMachine
    {
        public Snack[] Snacks;


        // if value is -1, then the customer used his card, therefore he can buy any snack
        private float totalMoneyValue;


        public SnackMachine(Snack[] snacks)
        {
            
            totalMoneyValue = 0;
            Snacks = snacks;
        }

        // to get the roduct details you need to detect the product by rows and columns
        public Snack GetProductDetails(string rowIndex, int columnIndex)
        {
            var snack = GetSnack(rowIndex, columnIndex);// to get the product location

            if (snack == null)//if there is no product
                throw new Exception("Invalid snack input");

            return snack;
        }

        public float GetTotalMoneyValue()
        {
            return totalMoneyValue;
        }

         //to let the customer get the product
        public Snack DispenceSnack(string rowIndex, int columnIndex)// to know the product location
        {
            var snack = GetSnack(rowIndex, columnIndex);//define the sack

            if (snack == null)
                throw new Exception("Invalid snack input");

            totalMoneyValue = 0;
            snack.Stock--;//if the customer gets the product it will be minus one from the VM


            return snack;
        }


        public bool ValidateMoney(Money money) // here is to validate if the money is USD
        {
            return money.Currency == Currency.USD;

        }

        // Here is the method that the customer will pay with.
        public void PayMoney( Money money)
        {
            if (!ValidateMoney(money))// if ts not USD currency 
                throw new Exception("Invalid payment");

            if (money is Card)
            {   
                totalMoneyValue = -1; // here is to control the card like there is nothing in the VM just the product price
            }
            else if(money is Coin coin)
            {
                totalMoneyValue += coin.Cents / 100; // /100 because its in cents
            }
            else if (money is Note note)
            {
                totalMoneyValue += note.Value;
            }
            else
            {
                throw new Exception("Payment cannot be processed");
            }
        }

        //Here to check if the product is available in the VM
        public bool IsSnackAvailable(string rowIndex, int columnIndex)
        {
            //If snack is available (does not equal null, return true), else return false
            var snack = GetSnack(rowIndex, columnIndex);
            if (snack == null)
            {
                return false;
            }
            return snack.Stock > 0;
        }

        //Here is to get the price of the product from the VM
        public float GetProductPrice(string rowIndex, int columnIndex)
        {
            var snack = GetSnack(rowIndex, columnIndex);

            if (snack == null)
                throw new Exception("Invalid snack input");

            return snack.Price;
        }

        //here is to check the money amount that the customer enters and if its enough to buy 
        public bool IsMoneyEnoughToBuySnack(string rowIndex, int columnIndex)// get the product 
        {
            var snack = GetSnack(rowIndex, columnIndex);

            if (snack == null)
                throw new Exception("Invalid snack input");

                return totalMoneyValue >= snack.Price; // to check if the amount is equals or more than the product price
        }

        //Here is to check if there is any change left after the buying prosess
        public float CalculateChange(string rowIndex, int columnIndex)
        {
            var snack = GetSnack(rowIndex, columnIndex);

            if (snack == null)
                throw new Exception("Invalid snack input");

            var moneyChange = totalMoneyValue - snack.Price;// to check if there is any change.

            if(moneyChange <= 0)
            {
                return 0;
            }

            return moneyChange; // if there is any change it will return to the customer
        }

       

        // Created for reusabilty
        private Snack GetSnack(string rowIndex, int columnIndex)
        {
            //Use Linq to get snack
            return  Snacks.FirstOrDefault(snack => snack.RowIndex.Equals(rowIndex, StringComparison.OrdinalIgnoreCase) & snack.ColumnIndex.Equals(columnIndex));

        }

        
    }
}
